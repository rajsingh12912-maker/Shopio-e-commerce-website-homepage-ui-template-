===========================================================================
Shopio - Premium Mobile eCommerce UI Template
===========================================================================
Created: 2026
Author: Your Name / Brand Name
File Type: HTML5 / CSS3 (Single File Architecture)
===========================================================================

Thank you for purchasing Shopio - Premium Mobile eCommerce UI Template!

Shopio is a lightweight, clean, and highly responsive mobile eCommerce UI
designed specifically for smartphones and mobile web browsers. 

---------------------------------------------------------------------------
FEATURES
---------------------------------------------------------------------------
* Single-File Layout: Everything (HTML & CSS) is contained inside a single index.html file.
* Zero Image Dependencies: Uses inline SVGs for product placeholders—no broken images!
* Google Fonts & FontAwesome integrated via CDN.
* Clean, modular code with descriptive comments.
* Easy customization via CSS root variables.

---------------------------------------------------------------------------
HOW TO USE / INSTALLATION
---------------------------------------------------------------------------
1. Extract the zip file.
2. Go to the "source_code" folder.
3. Double-click "index.html" to open the template instantly in any web browser.
4. For editing, open "index.html" in any text editor (like VS Code, Notepad++, etc.).

For a detailed customization guide, please open:
--> documentation/index.html

Thank you once again! If you like this product, please leave a rating on Codester.
